INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(1, '10', 'Adam', '20241', false, 'Gian');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(2, '10', 'Ghifari', '20242', false, 'Gian');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(3, '10', 'Rian', '20243', false, 'Gian');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(4, '10', 'Berli', '20244', false, 'Serly');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(5, '10', 'Syukri', '20245', false, 'Gian');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(6, '10', 'Rahmat', '20246', false, 'Serly');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(7, '10', 'Emil', '20247', false, 'Serly');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(8, '10', 'Rahman', '20248', false, 'Serly');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(10, '10', 'Fahri', '202410', false, 'Gian');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(11, '11', 'Sultan', '202411', false, 'Ayu Utami');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(12, '11', 'Kiki', '202412', false, 'Ayu Utami');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(13, '11', 'Zaskia', '202413', false, 'Ayu Utami');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(14, '11', 'Nurul', '202414', false, 'Ayu Utami');
INSERT INTO public.table_siswa
(id, kelas, nama_siswa, nis, status, wali_kelas)
VALUES(15, '11', 'Fatah', '202415', false, 'Ayu Utami');
