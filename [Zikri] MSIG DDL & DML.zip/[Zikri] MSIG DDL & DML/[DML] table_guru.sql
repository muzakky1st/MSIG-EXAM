INSERT INTO public.table_guru
(id, mata_pelajaran, nama_guru, status)
VALUES(1, 'Geografi', 'Gian', false);
INSERT INTO public.table_guru
(id, mata_pelajaran, nama_guru, status)
VALUES(3, 'Matematika', 'Serly', false);
INSERT INTO public.table_guru
(id, mata_pelajaran, nama_guru, status)
VALUES(4, 'TIK', 'Siska', false);
INSERT INTO public.table_guru
(id, mata_pelajaran, nama_guru, status)
VALUES(5, 'Bhs Inggris', 'Ayu Utami', false);
