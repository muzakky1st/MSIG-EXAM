INSERT INTO public.mata_pelajaran
(id, kelas, mata_pelajaran)
VALUES(1, '11', 'Bhs Inggris');
INSERT INTO public.mata_pelajaran
(id, kelas, mata_pelajaran)
VALUES(2, '10', 'Geografi');
INSERT INTO public.mata_pelajaran
(id, kelas, mata_pelajaran)
VALUES(3, '10', 'Matematika');
INSERT INTO public.mata_pelajaran
(id, kelas, mata_pelajaran)
VALUES(5, '10', 'Fisika Dasar');
