-- DROP SCHEMA public;

CREATE SCHEMA public AUTHORIZATION pg_database_owner;

COMMENT ON SCHEMA public IS 'standard public schema';

-- DROP SEQUENCE public.mata_pelajaran_id_seq;

CREATE SEQUENCE public.mata_pelajaran_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;
-- DROP SEQUENCE public.table_guru_id_seq;

CREATE SEQUENCE public.table_guru_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;
-- DROP SEQUENCE public.table_siswa_id_seq;

CREATE SEQUENCE public.table_siswa_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;-- public.mata_pelajaran definition

-- Drop table

-- DROP TABLE public.mata_pelajaran;

CREATE TABLE public.mata_pelajaran (
	id bigserial NOT NULL,
	kelas varchar(255) NULL,
	mata_pelajaran varchar(255) NULL,
	CONSTRAINT mata_pelajaran_pkey PRIMARY KEY (id)
);


-- public.table_guru definition

-- Drop table

-- DROP TABLE public.table_guru;

CREATE TABLE public.table_guru (
	id bigserial NOT NULL,
	mata_pelajaran varchar(255) NULL,
	nama_guru varchar(255) NULL,
	status bool NULL,
	CONSTRAINT table_guru_pkey PRIMARY KEY (id)
);


-- public.table_siswa definition

-- Drop table

-- DROP TABLE public.table_siswa;

CREATE TABLE public.table_siswa (
	id bigserial NOT NULL,
	kelas varchar(255) NULL,
	nama_siswa varchar(255) NULL,
	nis varchar(255) NULL,
	status bool NULL,
	wali_kelas varchar(255) NULL,
	CONSTRAINT table_siswa_pkey PRIMARY KEY (id)
);
